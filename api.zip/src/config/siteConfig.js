export const SITE = {
  heroVideoUrl: "", // keep empty; we'll use local fallback
  heroVideoLocal: "/assets/video/hero.mp4",
  heroPoster: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1600&auto=format&fit=crop",
  showcaseImage: "https://images.unsplash.com/photo-1524666041070-9d87656c25bb?q=80&w=1200&auto=format&fit=crop",
  enableStickyBlur: true,
};
